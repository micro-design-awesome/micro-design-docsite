| 项目名称                                               | 说明                                                         | 地址                          |
| ------------------------------------------------------ | ------------------------------------------------------------ | ----------------------------- |
| [Getnextjs **Themes**](https://getnextjsthemes.com/)   | 151 + 免费和高级 Next.Js 主题/模板                           | https://getnextjsthemes.com/  |
| [HTMLrev](https://htmlrev.com/)                        | 1500+ HTMLrev 上的免费 HTML 网站模板                         | https://htmlrev.com/          |
| [Websitevice](https://websitevice.com/images/logo.svg) | 提供灵感的网站示例                                           | https://websitevice.com/      |
| [portfoliorave](https://portfoliorave.com/)            | 提供灵感的作品集示例                                         | https://portfoliorave.com/    |
| [tailbits](https://www.tailbits.com/)                  | Tailbits 是使用 Tailwind CSS 制作的 UI 组件库。我们为各种类型的项目创建了 Tailwind 组件，并将它们集中在一个地方，以便您可以轻松找到设计项目所需的内容。从按钮到仪表板，我们应有尽有！ | https://www.tailbits.com/     |
| [cruip](https://cruip.com/)                            | 下一个项目的 Tailwind CSS 模板                               | https://cruip.com/            |
| [Codaily.dev](https://codaily.dev/)                    | 现代发展洞察和最佳实践                                       | https://codaily.dev/          |
| [Nextjs模板](https://nextjs-templates.com/)            | 16 + 适用于您即将到来的项目的最佳免费和高级 Next.js模板      | https://nextjs-templates.com/ |
| [Getnextjs **主题**](https://getnextjsthemes.com/)     | 167 + 免费和高级 Next.Js 主题/模板                           | https://getnextjsthemes.com/  |

