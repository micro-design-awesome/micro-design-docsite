<!--
 * @Description: 
 * @Author: xunzhaotech
 * @Email: luyb@xunzhaotech.com
 * @QQ: 1525572900
 * @Date: 2024-08-11 11:40:50
 * @LastEditTime: 2025-07-31 17:59:44
 * @LastEditors: xunzhaotech
-->
## 后端项目

| 项目                                                         | 说明 | GitHub | Gitee                                            |
| ------------------------------------------------------------ | ---- | ------ | ------------------------------------------------ |
| [micro-design-cloud](https://gitee.com/MicroDesign/micro-design-cloud) |      |        | https://gitee.com/MicroDesign/micro-design-cloud |
## 在线体验
- [演示地址【micro-design-ai】](https://microdesign.gitee.io/micro-design-ai/)
- [演示地址【micro-design-ui】](https://microdesign.gitee.io/micro-design-ui/)
- [演示地址【micro-design-admin】](https://microdesign.gitee.io/micro-design-admin/)
- [演示地址【micro-design-docs】](https://microdesign.gitee.io/micro-design-docs/)