```text
home: true
heroText: 基于element-plus二次封装组件
tagline: 高扩展的组件库
actionText: 快速开始
# actionLink: //
features:
  - title: 简洁至上
    details: 所有组件支持全量引入和按需引入
  - title: 高扩展性
    details: 全新的组件API设计，支持高度自定义
  - title: 全面覆盖
    details: 涵盖基础组件、通用组件和业务组件
```
#### 第一篇：GitBook制作文档并发布到GitHub
#### 第二篇：Hexo制作文档并发布到GitHub
#### 第三篇：Jekyll制作文档并发布到GitHub
#### 第四篇：Vuepress制作文档并发布到GitHub
#### 第五篇：Vitepress制作文档并发布到GitHub