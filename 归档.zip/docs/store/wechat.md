<!--
 * @Description: 
 * @Author: xunzhaotech
 * @Email: luyb@xunzhaotech.com
 * @QQ: 1525572900
 * @Date: 2025-07-12 13:16:22
 * @LastEditTime: 2025-07-12 13:16:28
 * @LastEditors: xunzhaotech
-->
<div class="text-blue-50">fghhfhfhfh</div>