<!--
 * @Description: 
 * @Author: xunzhaotech
 * @Email: luyb@xunzhaotech.com
 * @QQ: 1525572900
 * @Date: 2024-10-28 12:10:33
 * @LastEditTime: 2025-07-12 13:16:09
 * @LastEditors: xunzhaotech
-->
<div class="text-blue-50">fghhfhfhfh</div>