<!--
 * @Description: 
 * @Author: xunzhaotech
 * @Email: luyb@xunzhaotech.com
 * @QQ: 1525572900
 * @Date: 2025-07-12 17:10:19
 * @LastEditTime: 2025-07-12 19:45:03
 * @LastEditors: xunzhaotech
-->

<div class="product-grid">
<div class="product-card">
  <img src="/images/bi/bi.png" alt="新农业可视化平台" style="width: 100%; object-fit: cover;">
  <div style="padding: 20px;">
    <h3>新农业可视化平台</h3>
    <p>基于ERP的数字化车间可视化平台</p>
    <!-- <div class="price-tag">¥1299</div> -->
    <a href="http://8.130.100.142/index" class="action-btn">查看详情</a>
  </div>
</div>
</div>
