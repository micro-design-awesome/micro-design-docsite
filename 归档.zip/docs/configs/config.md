<!--
 * @Description: 
 * @Author: xunzhaotech
 * @Email: luyb@xunzhaotech.com
 * @QQ: 1525572900
 * @Date: 2024-04-28 22:24:26
 * @LastEditTime: 2024-04-28 22:28:23
 * @LastEditors: xunzhaotech
-->
## 关闭代理
```
yarn config set "strict-ssl" false -g //关闭代理
```