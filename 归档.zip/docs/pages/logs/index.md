<!--
 * @Author: luyb luyb@xunzhaotech.com
 * @Date: 2022-12-25 20:04:09
 * @LastEditors: xunzhaotech
 * @LastEditTime: 2024-01-01 22:31:22
 * @FilePath: \micro-design-docs\docs\pages\logs\index.md
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
# 更新日志
## 1.0.01（2023-01-05）
- 集成vitepress
## 1.0.00（2023-01-01）
- 初始化版本
