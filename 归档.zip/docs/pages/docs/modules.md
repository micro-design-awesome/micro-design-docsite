[micro-design-docs](README.md) / Exports

# micro-design-docs

## Table of contents

### Classes

- [MyClass](classes/MyClass.md)

### Interfaces

- [MyInterface](interfaces/MyInterface.md)
