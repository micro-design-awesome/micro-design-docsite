micro-design-docs / [Exports](modules.md)

<!--
 * @Author: luyb luyb@xunzhaotech.com
 * @Date: 2022-11-23 20:29:54
 * @LastEditors: luyb luyb@xunzhaotech.com
 * @LastEditTime: 2022-12-25 19:43:33
 * @FilePath: \micro-design-docs\README.md
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
# micro-design-docs

#### 介绍
基于MicroDesign UI 是一款基于前端微服务的UI框架和解决方案

#### 软件架构
- [TYPEDOC](https://typedoc.org/)
- [TSDoc](https://tsdoc.org/)
- [VitePress](https://vitepress.vuejs.org/)
::: tip
:::
::: warinig 
:::
::: danger
:::
#### 安装教程

1.  xxxx
2.  xxxx
3.  xxxx

#### 使用说明

1.  xxxx
2.  xxxx
3.  xxxx

#### 平台链接

1.  [微信支付](https://pay.weixin.qq.com/index.php/core/home/login)
2.  [TSDoc](https://tsdoc.org/)
3.  [TYPEDOC](https://typedoc.org/)

#### 开发工具
1.  使用 Readme\_XXX.md 来支持不同的语言，例如 Readme\_en.md, Readme\_zh.md
2.  Gitee 官方博客 [blog.gitee.com](https://blog.gitee.com)
3.  你可以 [https://gitee.com/explore](https://gitee.com/explore) 这个地址来了解 Gitee 上的优秀开源项目
4.  [GVP](https://gitee.com/gvp) 全称是 Gitee 最有价值开源项目，是综合评定出的优秀开源项目
5.  Gitee 官方提供的使用手册 [https://gitee.com/help](https://gitee.com/help)
6.  Gitee 封面人物是一档用来展示 Gitee 会员风采的栏目 [https://gitee.com/gitee-stars/](https://gitee.com/gitee-stars/)
7. [GitHub Desktop](https://desktop.github.com/)
