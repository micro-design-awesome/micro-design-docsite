[micro-design-docs](../README.md) / [Exports](../modules.md) / MyInterface

# Interface: MyInterface

接口

## Table of contents

### Properties

- [key1](MyInterface.md#key1)
- [key2](MyInterface.md#key2)

## Properties

### key1

• **key1**: `number`

属性1

#### Defined in

index.ts:12

___

### key2

• **key2**: `string`

属性2

#### Defined in

index.ts:15
