<!--
 * @Author: luyb luyb@xunzhaotech.com
 * @Date: 2022-11-27 17:06:29
 * @LastEditors: luyb luyb@xunzhaotech.com
 * @LastEditTime: 2022-12-03 17:05:30
 * @FilePath: \micro-design-docs\docs\pages\components\index.md
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
# 前端常用组件
## 组件
### 基础组件
- micro-component-field
- micro-component-form
- micro-component-layout
- micro-component-table
### 业务组件
- micro-component-order
- micro-component-pay
### 系统组件
- micro-component-login
- micro-component-register
## 插件
- micro-plugin-skin
- micro-plugin-top
## 主题
- micro-theme-hello
- micro-theme-pink