<!--
 * @Author: luyb luyb@xunzhaotech.com
 * @Date: 2022-12-27 12:00:33
 * @LastEditors: luyb luyb@xunzhaotech.com
 * @LastEditTime: 2022-12-27 12:15:10
 * @FilePath: \micro-design-docs\docs\pages\links\frontend\springboot.md
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
# SpringBoot
## 社区链接
- 官网:https://spring.io/projects/spring-boot
- GitHub:https://github.com/spring-projects/spring-boot
## 社区相关
::: tip [Java程序员进阶之路](https://tobebetterjavaer.com/)
- 官网:https://tobebetterjavaer.com/
- GitHub:https://github.com/fef-design/toBeBetterJavaer
:::

:::tip OpenAI-Java
- GitHub: https://github.com/TheoKanning/openai-java?utm_source=gold_browser_extension
:::

:::tip SpringAll
- 官网:https://mrbird.cc/
- Github:https://github.com/fef-design/SpringAll
:::

