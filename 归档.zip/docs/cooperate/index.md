<!--
 * @Description: 
 * @Author: xunzhaotech
 * @Email: luyb@xunzhaotech.com
 * @QQ: 1525572900
 * @Date: 2025-07-31 17:30:11
 * @LastEditTime: 2025-07-31 17:30:21
 * @LastEditors: xunzhaotech
-->
# 外包

承接各种软件开发：

- 本地知识库

- Ai智能体

- Ai工作流

- 小程序

- 安卓APP

- IOS APP

- 手机和PC网站

- mac、linux、windows等Electron桌面端软件

- 公众号

- ......

## 优势

- 价格优惠，比市面上便宜60%以上；

- 技术实力，技术大牛操刀；

- 后续保障，我们做的是长久的服务，不是一次性，做一个项目交一个朋友；


## 合作

或者你有软件需求，想要找一个团队长期合作，都可以来找我们，技术实力保障!!!